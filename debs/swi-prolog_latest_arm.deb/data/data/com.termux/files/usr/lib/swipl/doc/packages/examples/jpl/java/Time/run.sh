#!/data/data/com.termux/files/usr/bin/sh

. ../env.sh

run Time

