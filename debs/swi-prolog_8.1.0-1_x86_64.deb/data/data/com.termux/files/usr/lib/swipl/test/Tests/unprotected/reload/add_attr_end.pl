p :- a.
a.
%%%%%%%%%%%%%%%%
:- public p/0.
p :- a.
a.

